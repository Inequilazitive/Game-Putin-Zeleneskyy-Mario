import pygame
from pygame import mixer
import os
import random
import csv
import button  
#import pygame_widgets
#from pygame_widgets.button import Button
mixer.init()
pygame.init()

Total_width = 800
Total_Height = int(Total_width * 0.8)

win = pygame.display.set_mode((Total_width, Total_Height))
pygame.display.set_caption('Zelenesky vs Putin')

#set framerate
clock = pygame.time.Clock()
Frame_per_secondd = 60
#define game variables
Accelaration = 0.75
SCROLL_THRESH = 200
ROWS = 16
Columnss = 150
Head_SIZE = Total_Height // ROWS
Head_TYPES = 21
LEVEL_limit = 3
scroller_screen,scroller_background = 0,0
level = 1
The_start,The_start_intro = False,False


#action variables
Left_Movement,Right_Movement,gunshot = False,False,False
Sanction,Slapped_Sanction = False,False
#load music and sounds
pygame.mixer.music.load('D:\Games\Ba_Music.mp3')
pygame.mixer.music.set_volume(0.3)
pygame.mixer.music.play(-1, 0.0, 5000)
sound_jumping = pygame.mixer.Sound('D:\Games\Jumping.mp3')
sound_jumping.set_volume(0.05)
Sound_gunshot = pygame.mixer.Sound('D:\Games\Shooting.mp3')
Sound_gunshot.set_volume(0.05)
Sound_Sanction = pygame.mixer.Sound('D:\Games\Sanction_sound.mp3')
Sound_Sanction.set_volume(0.05)


#load images
#button images
Russia_start = pygame.image.load('D:\Games\start.png').convert_alpha()
Ukraine_exit = pygame.image.load('D:\Games\End.png').convert_alpha()
Russia_restart = pygame.image.load('D:\Games\start.png').convert_alpha()
#background
Tree1 = pygame.image.load('D:\Games\pine1.png').convert_alpha()
Tree2 = pygame.image.load('D:\Games\pine2.png').convert_alpha()
Motherland = pygame.image.load('D:\Games\motherland.png').convert_alpha()
Sky = pygame.image.load('D:\Games\sky_cloud.png').convert_alpha()
#store tiles in a list
img_iterative_ist = []
for x in range(Head_TYPES):
    img = pygame.image.load(f'D:\Games\Tiles\{x}.png')
    img = pygame.transform.scale(img, (Head_SIZE, Head_SIZE))
    img_iterative_ist.append(img)
#bullet
small_bullet = pygame.image.load('D:\Games\Bullet.png').convert_alpha()
#grenade
Sanction_img = pygame.image.load('D:\Games\Sanction.png').convert_alpha()
#pick up boxes
Canada_health = pygame.image.load('D:\Games\Canada.png').convert_alpha()
UK_ammo = pygame.image.load('D:\\Games\\UK.png').convert_alpha()
USA_Sanction = pygame.image.load('D:\\Games\\USA.png').convert_alpha()
item_boxes = {
    'Health'    : Canada_health,
    'Ammo'      : UK_ammo,
    'Grenade'   : USA_Sanction
}


#define colours
Background_colorrr = (144, 201, 120)
Death = (171,35,40)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
PINK = (235, 65, 54)

#define font
font = pygame.font.SysFont('Futura', 30)

def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    win.blit(img, (x, y))


def draw_bg():
    win.fill(Background_colorrr)
    width = Sky.get_width()
    for x in range(5):
        win.blit(Sky, ((x * width) - scroller_background * 0.5, 0))
        win.blit(Motherland, ((x * width) - scroller_background * 0.6, Total_Height - Motherland.get_height() - 300))
        win.blit(Tree1, ((x * width) - scroller_background * 0.7, Total_Height - Tree1.get_height() - 150))
        win.blit(Tree2, ((x * width) - scroller_background * 0.8, Total_Height - Tree2.get_height()))


#function to reset level
def reset_level():
    Putin_group.empty()
    bullet_group.empty()
    grenade_group.empty()
    explosion_group.empty()
    item_box_group.empty()
    decoration_group.empty()
    water_group.empty()
    exit_group.empty()

    #create empty tile list
    data = []
    for row in range(ROWS):
        r = [-1] * Columnss
        data.append(r)

    return data




class Soldier(pygame.sprite.Sprite):
    def __init__(self, char_type, x, y, scale, speed, ammo, grenades):
        pygame.sprite.Sprite.__init__(self)
        self.alive = True
        self.char_type = char_type
        self.speed = speed
        self.ammo = ammo
        self.start_ammo = ammo
        self.shoot_cooldown = 0
        self.grenades = grenades
        self.health = 100
        self.max_health = self.health
        self.direction = 1
        self.vel_y = 0
        self.jump = False
        self.in_air = True
        self.flip = False
        self.animation_list = []
        self.frame_index = 0
        self.action = 0
        self.update_time = pygame.time.get_ticks()
        #ai specific variables
        self.move_counter = 0
        self.vision = pygame.Rect(0, 0, 150, 20)
        self.idling = False
        self.idling_counter = 0
        
        #load all images for the Zeleneskys
        animation_types = ['Still', 'Running', 'Jumping', 'Died']
        for animation in animation_types:
            #reset temporary list of images
            temp_list = []
            #count number of files in the folder
            num_of_frames = len(os.listdir(f'D:\Games\{self.char_type}\{animation}'))
            for i in range(num_of_frames):
                img = pygame.image.load(f'D:\Games\{self.char_type}\{animation}\{i}.png').convert_alpha()
                img = pygame.transform.scale(img, (int(img.get_width() * scale), int(img.get_height() * scale)))
                temp_list.append(img)
            self.animation_list.append(temp_list)

        self.image = self.animation_list[self.action][self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.width = self.image.get_width()
        self.height = self.image.get_height()


    def update(self):
        self.update_animation()
        self.check_alive()
        #update cooldown
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1


    def move(self, moving_left, moving_right):
        #reset movement variables
        screen_scroll = 0
        dx = 0
        dy = 0

        #assign movement variables if moving left or right
        if moving_left:
            dx = -self.speed
            self.flip = True
            self.direction = -1
        if moving_right:
            dx = self.speed
            self.flip = False
            self.direction = 1

        #jump
        if self.jump == True and self.in_air == False:
            self.vel_y = -11
            self.jump = False
            self.in_air = True

        #apply gravity
        self.vel_y += Accelaration
        if self.vel_y > 10:
            self.vel_y
        dy += self.vel_y

        #check for collision
        for tile in world.obstacle_list:
            #check collision in the x direction
            if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                dx = 0
                #if the ai has hit a wall then make it turn around
                if self.char_type == 'Putin':
                    self.direction *= -1
                    self.move_counter = 0
            #check for collision in the y direction
            if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                #check if below the ground, i.e. jumping
                if self.vel_y < 0:
                    self.vel_y = 0
                    dy = tile[1].bottom - self.rect.top
                #check if above the ground, i.e. falling
                elif self.vel_y >= 0:
                    self.vel_y = 0
                    self.in_air = False
                    dy = tile[1].top - self.rect.bottom


        #check for collision with water
        if pygame.sprite.spritecollide(self, water_group, False):
            self.health = 0

        #check for collision with exit
        level_complete = False
        if pygame.sprite.spritecollide(self, exit_group, False):
            level_complete = True

        #check if fallen off the map
        if self.rect.bottom > Total_Height:
            self.health = 0


        #check if going off the edges of the screen
        if self.char_type == 'Zelenesky':
            if self.rect.left + dx < 0 or self.rect.right + dx > Total_width:
                dx = 0

        #update rectangle position
        self.rect.x += dx
        self.rect.y += dy

        #update scroll based on Zelenesky position
        if self.char_type == 'Zelenesky':
            if (self.rect.right > Total_width - SCROLL_THRESH and scroller_background < (world.level_length * Head_SIZE) - Total_width)\
                or (self.rect.left < SCROLL_THRESH and scroller_background > abs(dx)):
                self.rect.x -= dx
                screen_scroll = -dx

        return screen_scroll, level_complete



    def shoot(self):
        if self.shoot_cooldown == 0 and self.ammo > 0:
            self.shoot_cooldown = 20
            bullet = Bullet(self.rect.centerx + (0.75 * self.rect.size[0] * self.direction), self.rect.centery, self.direction)
            bullet_group.add(bullet)
            #reduce ammo
            self.ammo -= 1
            Sound_gunshot.play()


    def ai(self):
        if self.alive and Zelenesky.alive:
            if self.idling == False and random.randint(1, 200) == 1:
                self.update_action(0)#0: idle   
                self.idling = True
                self.idling_counter = 50
            #check if the ai in near the Zelenesky
            if self.vision.colliderect(Zelenesky.rect):
                #stop running and face the Zelenesky
                self.update_action(0)#0: idle
                #shoot
                self.shoot()
            else:
                if self.idling == False:
                    if self.direction == 1:
                        ai_moving_right = True
                    else:
                        ai_moving_right = False
                    ai_moving_left = not ai_moving_right
                    self.move(ai_moving_left, ai_moving_right)
                    self.update_action(1)#1: run
                    self.move_counter += 1
                    #update ai vision as the Putin moves
                    self.vision.center = (self.rect.centerx + 75 * self.direction, self.rect.centery)

                    if self.move_counter > Head_SIZE:
                        self.direction *= -1
                        self.move_counter *= -1
                else:
                    self.idling_counter -= 1
                    if self.idling_counter <= 0:
                        self.idling = False

        #scroll
        self.rect.x += scroller_screen


    def update_animation(self):
        #update animation
        ANIMATION_COOLDOWN = 100
        #update image depending on current frame
        self.image = self.animation_list[self.action][self.frame_index]
        #check if enough time has passed since the last update
        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1
        #if the animation has run out the reset back to the start
        if self.frame_index >= len(self.animation_list[self.action]):
            if self.action == 3:
                self.frame_index = len(self.animation_list[self.action]) - 1
            else:
                self.frame_index = 0



    def update_action(self, new_action):
        #check if the new action is different to the previous one
        if new_action != self.action:
            self.action = new_action
            #update the animation settings
            self.frame_index = 0
            self.update_time = pygame.time.get_ticks()



    def check_alive(self):
        if self.health <= 0:
            self.health = 0
            self.speed = 0
            self.alive = False
            self.update_action(3)


    def draw(self):
        win.blit(pygame.transform.flip(self.image, self.flip, False), self.rect)


class World():
    def __init__(self):
        self.obstacle_list = []

    def process_data(self, data):
        self.level_length = len(data[0])
        #iterate through each value in level data file
        for y, row in enumerate(data):
            for x, tile in enumerate(row):
                if tile >= 0:
                    img = img_iterative_ist[tile]
                    img_rect = img.get_rect()
                    img_rect.x = x * Head_SIZE
                    img_rect.y = y * Head_SIZE
                    tile_data = (img, img_rect)
                    if tile >= 0 and tile <= 8:
                        self.obstacle_list.append(tile_data)
                    elif tile >= 9 and tile <= 10:
                        water = Water(img, x * Head_SIZE, y * Head_SIZE)
                        water_group.add(water)
                    elif tile >= 11 and tile <= 14:
                        decoration = Decoration(img, x * Head_SIZE, y * Head_SIZE)
                        decoration_group.add(decoration)
                    elif tile == 15:#create Zelenesky
                        Zelenesky = Soldier('Zelenesky', x * Head_SIZE, y * Head_SIZE, 1.65, 5, 20, 5)
                        health_bar = HealthBar(10, 10, Zelenesky.health, Zelenesky.health)
                    elif tile == 16:#create enemies
                        Putin = Soldier('Putin', x * Head_SIZE, y * Head_SIZE, 1.65, 2, 20, 0)
                        Putin_group.add(Putin)
                    elif tile == 17:#create ammo box
                        item_box = ItemBox('Ammo', x * Head_SIZE, y * Head_SIZE)
                        item_box_group.add(item_box)
                    elif tile == 18:#create grenade box
                        item_box = ItemBox('Grenade', x * Head_SIZE, y * Head_SIZE)
                        item_box_group.add(item_box)
                    elif tile == 19:#create health box
                        item_box = ItemBox('Health', x * Head_SIZE, y * Head_SIZE)
                        item_box_group.add(item_box)
                    elif tile == 20:#create exit
                        exit = Exit(img, x * Head_SIZE, y * Head_SIZE)
                        exit_group.add(exit)

        return Zelenesky, health_bar


    def draw(self):
        for tile in self.obstacle_list:
            tile[1][0] += scroller_screen
            win.blit(tile[0], tile[1])


class Decoration(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + Head_SIZE // 2, y + (Head_SIZE - self.image.get_height()))

    def update(self):
        self.rect.x += scroller_screen


class Water(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + Head_SIZE // 2, y + (Head_SIZE - self.image.get_height()))

    def update(self):
        self.rect.x += scroller_screen

class Exit(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + Head_SIZE // 2, y + (Head_SIZE - self.image.get_height()))

    def update(self):
        self.rect.x += scroller_screen


class ItemBox(pygame.sprite.Sprite):
    def __init__(self, item_type, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.item_type = item_type
        self.image = item_boxes[self.item_type]
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + Head_SIZE // 2, y + (Head_SIZE - self.image.get_height()))


    def update(self):
        #scroll
        self.rect.x += scroller_screen
        #check if the Zelenesky has picked up the box
        if pygame.sprite.collide_rect(self, Zelenesky):
            #check what kind of box it was
            if self.item_type == 'Health':
                Zelenesky.health += 25
                if Zelenesky.health > Zelenesky.max_health:
                    Zelenesky.health = Zelenesky.max_health
            elif self.item_type == 'Ammo':
                Zelenesky.ammo += 15
            elif self.item_type == 'Grenade':
                Zelenesky.grenades += 3
            #delete the item box
            self.kill()
class Button():
    def __init__(self, x, y, image, scale):
        width = image.get_width()
        height = image.get_height()
        self.image = pygame.transform.scale(image, (int(width * scale), int(height * scale)))
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
        self.clicked = False

    def draw(self, surface):
        action = False

        #get mouse position
        pos = pygame.mouse.get_pos()

        #check mouseover and clicked conditions
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                action = True
                self.clicked = True

        if pygame.mouse.get_pressed()[0] == 0:
            self.clicked = False

        #draw button
        surface.blit(self.image, (self.rect.x, self.rect.y))

        return action

class HealthBar():
    def __init__(self, x, y, health, max_health):
        self.x = x
        self.y = y
        self.health = health
        self.max_health = max_health

    def draw(self, health):
        #update with new health
        self.health = health
        #calculate health ratio
        ratio = self.health / self.max_health
        pygame.draw.rect(win, BLACK, (self.x - 2, self.y - 2, 154, 24))
        pygame.draw.rect(win, Death, (self.x, self.y, 150, 20))
        pygame.draw.rect(win, GREEN, (self.x, self.y, 150 * ratio, 20))


class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        pygame.sprite.Sprite.__init__(self)
        self.speed = 10
        self.image = small_bullet
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.direction = direction

    def update(self):
        #move bullet
        self.rect.x += (self.direction * self.speed) + scroller_screen
        #check if bullet has gone off screen
        if self.rect.right < 0 or self.rect.left > Total_width:
            self.kill()
        #check for collision with level
        for tile in world.obstacle_list:
            if tile[1].colliderect(self.rect):
                self.kill()

        #check collision with characters
        if pygame.sprite.spritecollide(Zelenesky, bullet_group, False):
            if Zelenesky.alive:
                Zelenesky.health -= 5
                self.kill()
        for Putin in Putin_group:
            if pygame.sprite.spritecollide(Putin, bullet_group, False):
                if Putin.alive:
                    Putin.health -= 25
                    self.kill()



class Grenade(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        pygame.sprite.Sprite.__init__(self)
        self.timer = 100
        self.vel_y = -11
        self.speed = 7
        self.image = Sanction_img
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.direction = direction

    def update(self):
        self.vel_y += Accelaration
        dx = self.direction * self.speed
        dy = self.vel_y

        #check for collision with level
        for tile in world.obstacle_list:
            #check collision with walls
            if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                self.direction *= -1
                dx = self.direction * self.speed
            #check for collision in the y direction
            if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                self.speed = 0
                #check if below the ground, i.e. thrown up
                if self.vel_y < 0:
                    self.vel_y = 0
                    dy = tile[1].bottom - self.rect.top
                #check if above the ground, i.e. falling
                elif self.vel_y >= 0:
                    self.vel_y = 0
                    dy = tile[1].top - self.rect.bottom 


        #update grenade position
        self.rect.x += dx + scroller_screen
        self.rect.y += dy

        #countdown timer
        self.timer -= 1
        if self.timer <= 0:
            self.kill()
            Sound_Sanction.play()
            explosion = Explosion(self.rect.x, self.rect.y, 0.5)
            explosion_group.add(explosion)
            #do damage to anyone that is nearby
            if abs(self.rect.centerx - Zelenesky.rect.centerx) < Head_SIZE * 2 and \
                abs(self.rect.centery - Zelenesky.rect.centery) < Head_SIZE * 2:
                Zelenesky.health -= 50
            for Putin in Putin_group:
                if abs(self.rect.centerx - Putin.rect.centerx) < Head_SIZE * 2 and \
                    abs(self.rect.centery - Putin.rect.centery) < Head_SIZE * 2:
                    Putin.health -= 50



class Explosion(pygame.sprite.Sprite):
    def __init__(self, x, y, scale):
        pygame.sprite.Sprite.__init__(self)
        self.images = []
        for num in range(1, 5):
            img = pygame.image.load(f'D:\Games\Explosion\{num}.png').convert_alpha()
            img = pygame.transform.scale(img, (int(img.get_width() * scale), int(img.get_height() * scale)))
            self.images.append(img)
        self.frame_index = 0
        self.image = self.images[self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.counter = 0


    def update(self):
        #scroll
        self.rect.x += scroller_screen

        EXPLOSION_SPEED = 4
        #update explosion amimation
        self.counter += 1

        if self.counter >= EXPLOSION_SPEED:
            self.counter = 0
            self.frame_index += 1
            #if the animation is complete then delete the explosion
            if self.frame_index >= len(self.images):
                self.kill()
            else:
                self.image = self.images[self.frame_index]


class ScreenFade():
    def __init__(self, direction, colour, speed):
        self.direction = direction
        self.colour = colour
        self.speed = speed
        self.fade_counter = 0


    def fade(self):
        fade_complete = False
        self.fade_counter += self.speed
        if self.direction == 1:#whole screen fade
            pygame.draw.rect(win, self.colour, (0 - self.fade_counter, 0, Total_width // 2, Total_Height))
            pygame.draw.rect(win, self.colour, (Total_width // 2 + self.fade_counter, 0, Total_width, Total_Height))
            pygame.draw.rect(win, self.colour, (0, 0 - self.fade_counter, Total_width, Total_Height // 2))
            pygame.draw.rect(win, self.colour, (0, Total_Height // 2 +self.fade_counter, Total_width, Total_Height))
        if self.direction == 2:#vertical screen fade down
            pygame.draw.rect(win, self.colour, (0, 0, Total_width, 0 + self.fade_counter))
        if self.fade_counter >= Total_width:
            fade_complete = True

        return fade_complete


#create screen fades
intro_fade = ScreenFade(1, BLACK, 4)
death_fade = ScreenFade(2, PINK, 4)


#create buttons
start_button = Button(int(Total_width) // 2 - 130, int(Total_Height) // 2 - 150, Russia_start, 1)
exit_button = Button(int(Total_width) // 2 - 110, int(Total_Height) // 2 + 50, Ukraine_exit, 1)
restart_button = Button(int(Total_width) // 2 - 100, int(Total_Height) // 2 - 50, Russia_restart, 2)

#create sprite groups
Putin_group = pygame.sprite.Group()
bullet_group = pygame.sprite.Group()
grenade_group = pygame.sprite.Group()
explosion_group = pygame.sprite.Group()
item_box_group = pygame.sprite.Group()
decoration_group = pygame.sprite.Group()
water_group = pygame.sprite.Group()
exit_group = pygame.sprite.Group()



#create empty tile list
world_data = []
for row in range(ROWS):
    r = [-1] * Columnss
    world_data.append(r)
#load in level data and create world
with open(f'D:\Games\Level_{level}.csv', newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=',')
    for x, row in enumerate(reader):
        for y, tile in enumerate(row):
            world_data[x][y] = int(tile)
world = World()
Zelenesky, health_bar = world.process_data(world_data)



run = True
while run:

    clock.tick(Frame_per_secondd)

    if The_start == False:
        #draw menu
        win.fill(Background_colorrr)
        #add buttons
        if start_button.draw(win):
            The_start = True
            The_start_intro = True
        if exit_button.draw(win):
            run = False
    else:
        #update background
        draw_bg()
        #draw world map
        world.draw()
        #show Zelenesky health
        health_bar.draw(Zelenesky.health)
        #show ammo
        draw_text('AMMO: ', font, WHITE, 10, 35)
        for x in range(Zelenesky.ammo):
            win.blit(small_bullet, (90 + (x * 10), 40))
        #show grenades
        draw_text('GRENADES: ', font, WHITE, 10, 60)
        for x in range(Zelenesky.grenades):
            win.blit(Sanction_img, (135 + (x * 15), 60))


        Zelenesky.update()
        Zelenesky.draw()

        for Putin in Putin_group:
            Putin.ai()
            Putin.update()
            Putin.draw()

        #update and draw groups
        bullet_group.update()
        grenade_group.update()
        explosion_group.update()
        item_box_group.update()
        decoration_group.update()
        water_group.update()
        exit_group.update()
        bullet_group.draw(win)
        grenade_group.draw(win)
        explosion_group.draw(win)
        item_box_group.draw(win)
        decoration_group.draw(win)
        water_group.draw(win)
        exit_group.draw(win)

        #show intro
        if The_start_intro == True:
            if intro_fade.fade():
                The_start_intro = False
                intro_fade.fade_counter = 0


        #update Zelenesky actions
        if Zelenesky.alive:
            #shoot bullets
            if gunshot:
                Zelenesky.shoot()
            #throw grenades
            elif Sanction and Slapped_Sanction == False and Zelenesky.grenades > 0:
                Sanction = Grenade(Zelenesky.rect.centerx + (0.5 * Zelenesky.rect.size[0] * Zelenesky.direction),\
                            Zelenesky.rect.top, Zelenesky.direction)
                grenade_group.add(Sanction)
                #reduce grenades
                Zelenesky.grenades -= 1
                Slapped_Sanction = True
            if Zelenesky.in_air:
                Zelenesky.update_action(2)#2: jump
            elif Left_Movement or Right_Movement:
                Zelenesky.update_action(1)#1: run
            else:
                Zelenesky.update_action(0)#0: idle
            scroller_screen, level_complete = Zelenesky.move(Left_Movement, Right_Movement)
            scroller_background -= scroller_screen
            #check if Zelenesky has completed the level
            if level_complete:
                The_start_intro = True
                level += 1
                scroller_background = 0
                world_data = reset_level()
                if level <= LEVEL_limit:
                    #load in level data and create world
                    with open(f'D:\Games\Level_{level}.csv', newline='') as csvfile:
                        reader = csv.reader(csvfile, delimiter=',')
                        for x, row in enumerate(reader):
                            for y, tile in enumerate(row):
                                world_data[x][y] = int(tile)
                    world = World()
                    Zelenesky, health_bar = world.process_data(world_data)  
        else:
            scroller_screen = 0
            if death_fade.fade():
                if restart_button.draw(win):
                    death_fade.fade_counter = 0
                    The_start_intro = True
                    scroller_background = 0
                    world_data = reset_level()
                    #load in level data and create world
                    with open(f'D:\Games\Level_{level}.csv', newline='') as csvfile:
                        reader = csv.reader(csvfile, delimiter=',')
                        for x, row in enumerate(reader):
                            for y, tile in enumerate(row):
                                world_data[x][y] = int(tile)
                    world = World()
                    Zelenesky, health_bar = world.process_data(world_data)


    for event in pygame.event.get():
        #quit game
        if event.type == pygame.QUIT:
            run = False
        #keyboard presses
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                Left_Movement = True
            if event.key == pygame.K_d:
                Right_Movement = True
            if event.key == pygame.K_1:
                gunshot = True
            if event.key == pygame.K_q:
                Sanction = True
            if event.key == pygame.K_w and Zelenesky.alive:
                Zelenesky.jump = True
                sound_jumping.play()
            if event.key == pygame.K_ESCAPE:
                run = False


        #keyboard button released
        if event.type == pygame.KEYUP:
                Left_Movement = False
                if event.key == pygame.K_d:
                    Right_Movement = False
                if event.key == pygame.K_1:
                    gunshot = False
                if event.key == pygame.K_q:
                    Sanction = False
                    Slapped_Sanction = False


    pygame.display.update()




pygame.quit()